package segundo_parcial;

import java.io.Serializable;

public class Animal implements Comparable<Animal>,CSVSerializable, Serializable  {
    
    private int id;
    private String especie;
    private String nombre;
    private TipoAlimentacion alimentacion;
    private static final long serialVersionUID = 1L;

    public Animal(int id, String especie, String nombre, TipoAlimentacion alimentacion) {
        this.id = id;
        this.especie = especie;
        this.nombre = nombre;
        this.alimentacion = alimentacion;
    }

    @Override
    public String toString() {
        return "Animal{" + "id=" + id + ", especie=" + especie + ", nombre=" + nombre + ", alimentacion=" + alimentacion + '}';
    }
    

    @Override
    public int compareTo(Animal o) {
        return Integer.compare(this.id, o.id);
    }

    public String getNombre() {
        return nombre;
    }

    public String getEspecie() {
        return especie;
    }

    public TipoAlimentacion getAlimentacion() {
        return alimentacion;
    }
    

@Override
    public String toCSV() {
        return id + "," + nombre + "," + especie + "," + alimentacion.name();  
    }

    public static Animal fromCSV(String csv) {
        String[] datos = csv.split(",");
            if (datos.length == 4) {  
            int id = Integer.parseInt(datos[0]);
            String nombre = datos[1];
            String especie = datos[2];
            TipoAlimentacion alimentacion = TipoAlimentacion.valueOf(datos[3]);

            return new Animal(id, nombre, especie, alimentacion);
        }
        return null;
    } 
}


