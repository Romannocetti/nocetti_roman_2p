package segundo_parcial;

public interface CSVSerializable {

    String toCSV();

    public interface CSVDeserializer<T> {
        T fromCSV(String csv);
    }
}
